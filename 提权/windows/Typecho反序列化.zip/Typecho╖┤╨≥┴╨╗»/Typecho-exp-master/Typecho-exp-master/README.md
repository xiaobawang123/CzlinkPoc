# Typecho-exp
typecho反序列化漏洞exp，一键写shell                                                                                                         
漏洞分析：https://www.ghtwf01.cn/index.php/archives/976/
# 使用指南
python typecho-exp.py -u "http://127.0.0.1/typecho"
